import React, { useState } from 'react';
import { ShoppingCart, Search, Menu, X, Star, Filter, Plus, Minus } from 'lucide-react';

interface Game {
  id: number;
  title: string;
  platform: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  condition: string;
  year: number;
  description: string;
}

interface CartItem extends Game {
  quantity: number;
}

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const games: Game[] = [
    {
      id: 1,
      title: "The Legend of Zelda: Breath of the Wild",
      platform: "Nintendo Switch",
      price: 450000,
      image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "adventure",
      rating: 4.9,
      condition: "Like New",
      year: 2017,
      description: "Petualangan epik Link di dunia Hyrule yang luas dan terbuka."
    },
    {
      id: 2,
      title: "Super Mario Odyssey",
      platform: "Nintendo Switch",
      price: 400000,
      image: "https://images.pexels.com/photos/1293261/pexels-photo-1293261.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "platformer",
      rating: 4.8,
      condition: "Excellent",
      year: 2017,
      description: "Mario melakukan perjalanan melintasi berbagai kingdom untuk menyelamatkan Princess Peach."
    },
    {
      id: 3,
      title: "God of War",
      platform: "PlayStation 4",
      price: 350000,
      image: "https://images.pexels.com/photos/21067/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=400",
      category: "action",
      rating: 4.7,
      condition: "Very Good",
      year: 2018,
      description: "Kratos dan putranya Atreus bertualang di dunia mitologi Norse."
    },
    {
      id: 4,
      title: "Cyberpunk 2077",
      platform: "PlayStation 5",
      price: 300000,
      image: "https://images.pexels.com/photos/194096/pexels-photo-194096.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "rpg",
      rating: 4.2,
      condition: "Good",
      year: 2020,
      description: "RPG futuristik di Night City yang penuh dengan teknologi cyberpunk."
    },
    {
      id: 5,
      title: "Animal Crossing: New Horizons",
      platform: "Nintendo Switch",
      price: 420000,
      image: "https://images.pexels.com/photos/1906157/pexels-photo-1906157.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "simulation",
      rating: 4.6,
      condition: "Like New",
      year: 2020,
      description: "Simulasi kehidupan santai di pulau tropis yang dapat dikustomisasi."
    },
    {
      id: 6,
      title: "Spider-Man: Miles Morales",
      platform: "PlayStation 5",
      price: 380000,
      image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "action",
      rating: 4.5,
      condition: "Excellent",
      year: 2020,
      description: "Miles Morales mengambil peran sebagai Spider-Man di New York."
    }
  ];

  const categories = [
    { id: 'all', name: 'Semua Kategori' },
    { id: 'action', name: 'Action' },
    { id: 'adventure', name: 'Adventure' },
    { id: 'rpg', name: 'RPG' },
    { id: 'platformer', name: 'Platformer' },
    { id: 'simulation', name: 'Simulation' }
  ];

  const filteredGames = games.filter(game => {
    const matchesSearch = game.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         game.platform.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || game.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (game: Game) => {
    setCart(prev => {
      const existingItem = prev.find(item => item.id === game.id);
      if (existingItem) {
        return prev.map(item =>
          item.id === game.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...game, quantity: 1 }];
    });
  };

  const updateQuantity = (id: number, quantity: number) => {
    if (quantity === 0) {
      setCart(prev => prev.filter(item => item.id !== id));
    } else {
      setCart(prev => prev.map(item =>
        item.id === id ? { ...item, quantity } : item
      ));
    }
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const Header = () => (
    <header className="bg-gray-900 text-white sticky top-0 z-50 border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <button
              onClick={() => setCurrentPage('home')}
              className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"
            >
              GameCassette
            </button>
          </div>

          <nav className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <button
                onClick={() => setCurrentPage('home')}
                className="hover:text-purple-400 transition-colors duration-200"
              >
                Beranda
              </button>
              <button
                onClick={() => setCurrentPage('catalog')}
                className="hover:text-purple-400 transition-colors duration-200"
              >
                Katalog
              </button>
              <button className="hover:text-purple-400 transition-colors duration-200">
                Tentang
              </button>
              <button className="hover:text-purple-400 transition-colors duration-200">
                Kontak
              </button>
            </div>
          </nav>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors duration-200"
            >
              <ShoppingCart className="w-6 h-6" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-2 -right-2 bg-purple-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors duration-200"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-gray-800 border-t border-gray-700">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <button
              onClick={() => {
                setCurrentPage('home');
                setIsMobileMenuOpen(false);
              }}
              className="block px-3 py-2 text-base font-medium hover:text-purple-400 transition-colors duration-200"
            >
              Beranda
            </button>
            <button
              onClick={() => {
                setCurrentPage('catalog');
                setIsMobileMenuOpen(false);
              }}
              className="block px-3 py-2 text-base font-medium hover:text-purple-400 transition-colors duration-200"
            >
              Katalog
            </button>
          </div>
        </div>
      )}
    </header>
  );

  const HomePage = () => (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-purple-900 via-gray-900 to-pink-900 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Koleksi Game
              </span>
              <br />
              Terlengkap & Terpercaya
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Temukan kaset game favorit Anda dari berbagai platform gaming terpopuler. 
              Kualitas terjamin, harga terbaik, dan layanan memuaskan.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => setCurrentPage('catalog')}
                className="px-8 py-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transform hover:scale-105 transition-all duration-200"
              >
                Jelajahi Katalog
              </button>
              <button className="px-8 py-3 border border-gray-600 rounded-lg font-semibold hover:border-purple-400 hover:text-purple-400 transition-colors duration-200">
                Pelajari Lebih Lanjut
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Games */}
      <section className="py-16 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Game <span className="text-purple-400">Terpopuler</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {games.slice(0, 3).map((game) => (
              <div
                key={game.id}
                className="bg-gray-900 rounded-xl overflow-hidden border border-gray-700 hover:border-purple-500 transition-all duration-300 transform hover:scale-105"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{game.title}</h3>
                  <p className="text-gray-400 mb-2">{game.platform}</p>
                  <div className="flex items-center mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(game.rating) ? 'text-yellow-400 fill-current' : 'text-gray-600'
                          }`}
                        />
                      ))}
                      <span className="ml-2 text-gray-400">{game.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-purple-400">
                      {formatPrice(game.price)}
                    </span>
                    <button
                      onClick={() => addToCart(game)}
                      className="px-4 py-2 bg-purple-500 rounded-lg hover:bg-purple-600 transition-colors duration-200"
                    >
                      Beli
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Mengapa Memilih <span className="text-purple-400">GameCassette</span>?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-gray-800 rounded-xl border border-gray-700">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-4">Kualitas Terjamin</h3>
              <p className="text-gray-400">
                Semua kaset game telah melalui pengecekan kualitas ketat dan dijamin berfungsi dengan baik.
              </p>
            </div>
            <div className="text-center p-6 bg-gray-800 rounded-xl border border-gray-700">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingCart className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-4">Pengiriman Cepat</h3>
              <p className="text-gray-400">
                Pesanan Anda akan diproses dan dikirim dengan cepat menggunakan layanan kurir terpercaya.
              </p>
            </div>
            <div className="text-center p-6 bg-gray-800 rounded-xl border border-gray-700">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-4">Koleksi Lengkap</h3>
              <p className="text-gray-400">
                Dari game retro hingga rilisan terbaru, kami memiliki koleksi game yang lengkap dan terus bertambah.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );

  const CatalogPage = () => (
    <div className="min-h-screen bg-gray-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-8">
          Katalog <span className="text-purple-400">Game</span>
        </h1>

        {/* Search and Filter */}
        <div className="mb-8 flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Cari game atau platform..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-600 rounded-lg focus:border-purple-500 focus:outline-none"
            />
          </div>
          
          <div className="flex gap-4">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg focus:border-purple-500 focus:outline-none"
            >
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
            <button className="px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg hover:border-purple-500 transition-colors duration-200">
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredGames.map((game) => (
            <div
              key={game.id}
              className="bg-gray-800 rounded-xl overflow-hidden border border-gray-700 hover:border-purple-500 transition-all duration-300 transform hover:scale-105 cursor-pointer"
              onClick={() => setSelectedGame(game)}
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={game.image}
                  alt={game.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1 line-clamp-2">{game.title}</h3>
                <p className="text-sm text-gray-400 mb-2">{game.platform}</p>
                <div className="flex items-center mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < Math.floor(game.rating) ? 'text-yellow-400 fill-current' : 'text-gray-600'
                        }`}
                      />
                    ))}
                    <span className="ml-1 text-xs text-gray-400">{game.rating}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-400">
                    {formatPrice(game.price)}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(game);
                    }}
                    className="px-3 py-1 bg-purple-500 rounded-lg hover:bg-purple-600 transition-colors duration-200 text-sm"
                  >
                    Beli
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredGames.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400 text-lg">Tidak ada game yang ditemukan.</p>
          </div>
        )}
      </div>
    </div>
  );

  const GameDetail = ({ game }: { game: Game }) => (
    <div className="min-h-screen bg-gray-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => setSelectedGame(null)}
          className="mb-6 px-4 py-2 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors duration-200"
        >
          ← Kembali
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="aspect-square overflow-hidden rounded-xl">
            <img
              src={game.image}
              alt={game.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">{game.title}</h1>
              <p className="text-xl text-gray-400 mb-4">{game.platform}</p>
              <div className="flex items-center mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(game.rating) ? 'text-yellow-400 fill-current' : 'text-gray-600'
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-gray-400">{game.rating} dari 5</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Kondisi:</span>
                <span className="font-medium">{game.condition}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Tahun Rilis:</span>
                <span className="font-medium">{game.year}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Kategori:</span>
                <span className="font-medium capitalize">{game.category}</span>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-2">Deskripsi</h3>
              <p className="text-gray-300 leading-relaxed">{game.description}</p>
            </div>

            <div className="space-y-4">
              <div className="text-3xl font-bold text-purple-400">
                {formatPrice(game.price)}
              </div>
              <button
                onClick={() => addToCart(game)}
                className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200"
              >
                Tambah ke Keranjang
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const CartSidebar = () => (
    <div className={`fixed inset-0 z-50 ${isCartOpen ? '' : 'pointer-events-none'}`}>
      <div
        className={`absolute inset-0 bg-black transition-opacity duration-300 ${
          isCartOpen ? 'opacity-50' : 'opacity-0'
        }`}
        onClick={() => setIsCartOpen(false)}
      />
      <div
        className={`absolute right-0 top-0 h-full w-96 bg-gray-900 shadow-xl transform transition-transform duration-300 ${
          isCartOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-white">Keranjang Belanja</h2>
          <button
            onClick={() => setIsCartOpen(false)}
            className="p-2 text-gray-400 hover:text-white transition-colors duration-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {cart.length === 0 ? (
            <p className="text-gray-400 text-center py-8">Keranjang Anda kosong</p>
          ) : (
            <div className="space-y-4">
              {cart.map((item) => (
                <div key={item.id} className="bg-gray-800 rounded-lg p-4">
                  <h3 className="font-medium text-white mb-2 line-clamp-2">{item.title}</h3>
                  <p className="text-sm text-gray-400 mb-2">{item.platform}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-purple-400 font-bold">
                      {formatPrice(item.price)}
                    </span>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1 bg-gray-700 rounded hover:bg-gray-600 transition-colors duration-200"
                      >
                        <Minus className="w-4 h-4 text-white" />
                      </button>
                      <span className="text-white font-medium w-8 text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1 bg-gray-700 rounded hover:bg-gray-600 transition-colors duration-200"
                      >
                        <Plus className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {cart.length > 0 && (
          <div className="border-t border-gray-700 p-4">
            <div className="flex items-center justify-between mb-4">
              <span className="text-lg font-bold text-white">Total:</span>
              <span className="text-xl font-bold text-purple-400">
                {formatPrice(getTotalPrice())}
              </span>
            </div>
            <button className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg font-semibold text-white hover:from-purple-600 hover:to-pink-600 transition-all duration-200">
              Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );

  const renderPage = () => {
    if (selectedGame) {
      return <GameDetail game={selectedGame} />;
    }
    
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'catalog':
        return <CatalogPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      {renderPage()}
      <CartSidebar />
    </div>
  );
}

export default App;