# 🎮 GameCassette - Video Game Store

Sebuah website e-commerce modern untuk penjualan kaset video game dengan desain yang menarik dan user experience yang optimal.

![GameCassette Preview](https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=800)

## 🌟 Live Demo

🚀 **Website Live**: [https://video-game-cassette-y8w8.bolt.host](https://video-game-cassette-y8w8.bolt.host)

## ✨ Fitur Utama

### 🛍️ E-Commerce Features
- **Katalog Produk Lengkap** - Tampilan grid responsif dengan filter dan pencarian
- **Keranjang Belanja Interaktif** - Sidebar cart dengan update quantity real-time
- **Detail Produk** - Halaman detail dengan informasi lengkap dan rating
- **Sistem Filter** - Filter berdasarkan kategori, platform, dan pencarian
- **Responsive Design** - Optimal di desktop, tablet, dan mobile

### 🎨 Design & UX
- **Modern Gaming Aesthetic** - Tema gelap dengan aksen neon purple/pink
- **Smooth Animations** - Hover effects dan micro-interactions
- **Professional Layout** - Clean typography dan spacing yang konsisten
- **Mobile-First Approach** - Pengalaman yang seamless di semua device

### 🔧 Technical Features
- **React 18** dengan TypeScript untuk type safety
- **Tailwind CSS** untuk styling yang efficient
- **Lucide React** untuk icon set yang konsisten
- **Vite** untuk development yang cepat
- **Component-based Architecture** untuk maintainability

## 🛠️ Tech Stack

- **Frontend**: React 18, TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Deployment**: Bolt Hosting

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 atau lebih baru)
- npm atau yarn

### Installation

1. **Clone repository**
   ```bash
   git clone https://github.com/yourusername/gamecassette-store.git
   cd gamecassette-store
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Open browser**
   ```
   http://localhost:5173
   ```

### Build untuk Production

```bash
npm run build
npm run preview
```

## 📁 Project Structure

```
gamecassette-store/
├── src/
│   ├── App.tsx          # Main application component
│   ├── main.tsx         # Application entry point
│   ├── index.css        # Global styles with Tailwind
│   └── vite-env.d.ts    # Vite type definitions
├── public/
├── index.html           # HTML template
├── package.json         # Dependencies dan scripts
├── vite.config.ts       # Vite configuration
├── tailwind.config.js   # Tailwind CSS configuration
├── tsconfig.json        # TypeScript configuration
└── README.md
```

## 🎮 Fitur Produk

### Game Categories
- **Action** - Game aksi dan petualangan
- **Adventure** - Game petualangan dan eksplorasi  
- **RPG** - Role-playing games
- **Platformer** - Game platform dan jumping
- **Simulation** - Game simulasi kehidupan

### Platform Support
- Nintendo Switch
- PlayStation 4
- PlayStation 5
- Xbox Series X/S
- PC Gaming

### Product Features
- Rating dan review system
- Kondisi produk (Like New, Excellent, Very Good, Good)
- Tahun rilis dan informasi detail
- Harga dalam format Rupiah
- Gambar produk berkualitas tinggi

## 🔮 Roadmap & Future Features

- [ ] **User Authentication** - Login/register system
- [ ] **Payment Integration** - Integrasi dengan payment gateway
- [ ] **Order Management** - Sistem tracking pesanan
- [ ] **Admin Dashboard** - Panel admin untuk manage produk
- [ ] **Wishlist Feature** - Simpan game favorit
- [ ] **Review System** - User reviews dan rating
- [ ] **Search Enhancement** - Advanced search dengan filter
- [ ] **Recommendation Engine** - Rekomendasi produk personal

## 🤝 Contributing

Kontribusi sangat diterima! Silakan:

1. Fork repository ini
2. Buat feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buka Pull Request

## 📝 License

Distributed under the MIT License. See `LICENSE` for more information.

## 👨‍💻 Author

**Your Name**
- GitHub: [@yourusername](https://github.com/yourusername)
- Email: your.email@example.com

## 🙏 Acknowledgments

- [React](https://reactjs.org/) - UI Library
- [Tailwind CSS](https://tailwindcss.com/) - CSS Framework
- [Lucide React](https://lucide.dev/) - Icon Library
- [Vite](https://vitejs.dev/) - Build Tool
- [Pexels](https://pexels.com/) - Stock Images

---

⭐ **Jika project ini membantu, jangan lupa berikan star!** ⭐